define(['angular', 'components/shared/index'], function (angular) {

    var _ = require('underscore');
    var ppContactApp = angular.module('ppContactApp', ['powerSchoolModule']).run(function($rootScope, $http) {
        
        var getPhoneTypeCodes = function(){
            let endpoint = 'codeset.json?type=Phone';
                $http.get(endpoint).then( function (response) {
                    var codeset = response.data;
                    codeset.pop();
                    $rootScope.phoneTypeCodes = codeset;
                });
        };

        var getEmailTypeCodes = function(){
            let endpoint = 'codeset.json?type=Email';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.emailTypeCodes = codeset;
            });

        };

        var getAddressTypeCodes = function(){
            let endpoint = 'codeset.json?type=Address';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.addressTypeCodes = codeset;
            });

        };

        var getStateTypeCodes = function(){
            let endpoint = 'codeset.json?type=State';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.stateTypeCodes = codeset;
            });

        };

        var getCountyTypeCodes = function(){
            let endpoint = 'codeset.json?type=County';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.countyTypeCodes = codeset;
            });

        };

        var getCountyFipsCodes = function(){
            let endpoint = 'countyfipscodes.json';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.countyFipsCodes = codeset;
            });

        };

        var getCountryTypeCodes = function(){
            let endpoint = 'codeset.json?type=Country';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.countryTypeCodes = codeset;
            });

        };
        
        getPhoneTypeCodes();
        getEmailTypeCodes();
        getAddressTypeCodes();
        getStateTypeCodes();
        getCountyTypeCodes();
        getCountyFipsCodes();
        getCountryTypeCodes();

    });

    ppContactApp.controller('phoneController', function($scope, $rootScope, $http, $httpParamSerializer){
    
        $scope.personphone = {};
        $scope.personphonenumberassoc = {};
        $scope.phoneTypes = [];
        
        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                    
                    $scope.personphonenumberassoc = angular.copy(properties.data);
                    $scope.phoneTypes = angular.copy($rootScope.phoneTypeCodes);
                    //$scope.phonenumber_requestid = crypto.randomUUID();
                    callback();
                });
                
                $scope.$emit('cancel.drawer.event', function(callback, properties) {
                    angular.copy({}, $scope.personphonenumberassoc);
                    callback();
                });
                
                $scope.$emit('save.drawer.event', function(callback, properties) {
                    
                    var phoneForm = document.forms['phoneform'];
                    var phoneFormElements = phoneForm.elements;
                    var phoneFields = {};
                    var phoneAssocFields = {};
                    var ppcm_personid = '';
                    var ppcm_phonenumber = '';
                    var ppcm_phonenumberext = '';
                    var ppcm_phonepriorityorder = '';
                    var newphone = false;

                    angular.forEach(phoneFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[PHONENUMBER')) {
                            phoneFields[element.name] = element.value;
                        }
                        if(element.name == 'ppcm_personid'){
                            ppcm_personid = element.value;
                        }
                        if(element.name == 'ppcm_phonepriorityorder'){
                            ppcm_phonepriorityorder = element.value;
                        }
                        if(element.name.endsWith(']PhoneNumber')){
                            ppcm_phonenumber = element.value;
                        }
                        if(element.name.endsWith(']PhoneNumberExt')){
                            ppcm_phonenumberext = element.value;
                        }
                    });
                    phoneFields['ac'] = "autosendupdate";

                    angular.forEach(phoneFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[PERSONPHONENUMBERASSOC')) {
                            phoneAssocFields[element.name] = element.value;
                            /*
                            if (element.name.includes(']PhoneNumberPriorityOrder')) {
                                phoneAssocFields[element.name] = ppcm_phonepriorityorder;
                            }
                            */
                            if (element.name.includes('PersonPhoneNumberAssocID') && element.value == '') {
                                newphone = true;
                            }
                        }
                    });
                    phoneAssocFields['ac'] = "autosendupdate";    
                    
                    $http({
                        method: 'POST',
                        url: 'white.html',
                        data: $j.param(phoneFields),
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).then(function (response) {
                        return $http({
                            method: 'GET',
                            url: 'getIdfromPhonenumber.json?pn='+ppcm_phonenumber+'&pnx='+ppcm_phonenumberext,
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        }, response.data); // Chain the second request to get the new phone number id
                    }).then(function(response){
                        if(newphone){
                            phoneAssocFields['CF-[PERSONPHONENUMBERASSOC:-99]PhoneNumberID'] = response.data;
                            phoneAssocFields['CF-[PERSONPHONENUMBERASSOC:-99]PersonID'] = ppcm_personid;
                            phoneAssocFields['CF-[PERSONPHONENUMBERASSOC:-99]PhoneNumberPriorityOrder'] = ppcm_phonepriorityorder;
                        }
                        return $http({
                            method: 'POST',
                            url: 'white.html',
                            data: $j.param(phoneAssocFields),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        }, response.data); // Chain the third request that creates the person phone number association
                    }).finally(function (response) {
                        $rootScope.$emit("CallRefreshPhoneNumbers", {});
                    });
                    angular.copy({}, $scope.personphonenumberassoc);
                    callback();
                });
                
        };
        
        init();
    
    }); // end phone controller

    ppContactApp.controller('removephoneController', function($scope, $rootScope, $http, $httpParamSerializer){
       
        $scope.phone = {};
        
        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                 $scope.phone = properties.data;
                 callback();
             });
             
             $scope.$emit('cancel.drawer.event', function(callback, properties) {
                 // TODO: clear contact object
                 callback();
             });
             
             $scope.$emit('save.drawer.event', function(callback, properties) {
                 // TODO: clear phone object
                 
                 var postData = {};
                 
                 postData["DD-PERSONPHONENUMBERASSOC.PersonPhoneNumberAssocID:" + $scope.phone["personphonenumberassocId"]] = "1";
                 postData["ac"] = "autosendupdate";
                 
                 $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
     
                 $http({
                     method: 'POST',
                     url: 'white.html',
                     data: $j.param(postData),
                     headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                 }).then(function (response) {
                     $rootScope.$emit("CallRefreshPhoneNumbers", {});
                 });
                 
                 callback();
             });
             
        };
        
        init();
        
    }); // end remove phone controller

    ppContactApp.controller('emailController', function($scope, $rootScope, $http, $httpParamSerializer){
        
        $scope.personemail = {};
        $scope.personemailassoc = {};
        $scope.emailTypes = [];
        
        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                    $scope.personemailassoc = angular.copy(properties.data);
                    $scope.emailTypes = angular.copy($rootScope.emailTypeCodes);
                    callback();
                });
                
                $scope.$emit('cancel.drawer.event', function(callback, properties) {
                    angular.copy({}, $scope.personemailassoc);
                    callback();
                });
                
                $scope.$emit('save.drawer.event', function(callback, properties) {
                    
                    var emailForm = document.forms['emailaddressform'];
                    var emailFormElements = emailForm.elements;
                    var emailFields = {};
                    var emailAssocFields = {};
                    var ppcm_personid = '';
                    var ppcm_emailaddress = '';
                    var ppcm_emailpriorityorder = '';
                    var newemail = false;

                    angular.forEach(emailFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[EMAILADDRESS')) {
                            emailFields[element.name] = element.value;
                        }
                        if(element.name == 'ppcm_personid'){
                            ppcm_personid = element.value;
                        }
                        if(element.name == 'ppcm_emailpriorityorder'){
                            ppcm_emailpriorityorder = element.value;
                        }
                        if(element.name.endsWith(']EmailAddress')){
                            ppcm_emailaddress = element.value;
                        }
                    });
                    emailFields['ac'] = "autosendupdate";

                    angular.forEach(emailFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[PERSONEMAILADDRESSASSOC')) {
                            emailAssocFields[element.name] = element.value;
                            if (element.name.includes('PersonEmailAddressAssocID') && element.value == '') {
                                newemail = true;
                            }
                        }
                    });
                    emailAssocFields['ac'] = "autosendupdate";    
                    
                    $http({
                        method: 'POST',
                        url: 'white.html',
                        data: $j.param(emailFields),
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).then(function (response) {
                        return $http({
                            method: 'GET',
                            url: 'getIdfromEmailAddress.json?ea='+ppcm_emailaddress,
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        }, response.data); // Chain the second request to get the new phone number id
                    }).then(function(response){
                        if(newemail){
                            emailAssocFields['CF-[PERSONEMAILADDRESSASSOC:-99]EmailAddressID'] = response.data;
                            emailAssocFields['CF-[PERSONEMAILADDRESSASSOC:-99]PersonID'] = ppcm_personid;
                            emailAssocFields['CF-[PERSONEMAILADDRESSASSOC:-99]EmailAddressPriorityOrder'] = ppcm_emailpriorityorder;
                        }
                        return $http({
                            method: 'POST',
                            url: 'white.html',
                            data: $j.param(emailAssocFields),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        }, response.data); // Chain the third request that creates the person phone number association
                    }).finally(function (response) {
                        $rootScope.$emit("CallRefreshEmailAddresses", {});
                    });
                    angular.copy({}, $scope.personemailassoc);
                    callback();
                });
                
        };
        
        init();

    }); // end email controller

    ppContactApp.controller('removeemailController', function($scope, $rootScope, $http, $httpParamSerializer){
        $scope.emailaddress = {};
        
        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                 $scope.emailaddress = angular.copy(properties.data);
                 callback();
             });
             
             $scope.$emit('cancel.drawer.event', function(callback, properties) {
                $scope.emailaddress = angular.copy({});
                 callback();
             });
             
             $scope.$emit('save.drawer.event', function(callback, properties) {
                 var postData = {};
                 
                 postData["DD-PERSONEMAILADDRESSASSOC.PersonEmailAddressAssocID:" + $scope.emailaddress["emailaddressassocId"]] = "1";
                 postData["ac"] = "autosendupdate";
                 
                 $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
     
                 $http({
                     method: 'POST',
                     url: 'white.html',
                     data: $j.param(postData),
                     headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                 }).then(function (response) {
                     $rootScope.$emit("CallRefreshEmailAddresses", {});
                 });
                 $scope.emailaddress = angular.copy({});
                 callback();
             });
             
        };
        
        init();
    }); // end remove email controller

    ppContactApp.controller('addressController', function($scope, $rootScope, $http, $httpParamSerializer){
        $scope.personaddress = {};
        $scope.personaddressassoc = {};
        $scope.addressTypes = [];
        $scope.stateTypes = [];
        $scope.countyTypes = [];
        $scope.countyFipsCodes = [];
        $scope.countryTypes = [];
        $scope.selectedCounty = "";
        $scope.selectedCountyFipsCode = "";
        
        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                    
                    $scope.personaddressassoc = angular.copy(properties.data);
                    $scope.addressTypes = angular.copy($rootScope.addressTypeCodes);
                    $scope.stateTypes = angular.copy($rootScope.stateTypeCodes);
                    $scope.countyTypes = angular.copy($rootScope.countyTypeCodes);
                    $scope.countyFipsCodes = angular.copy($rootScope.countyFipsCodes);
                    $scope.countryTypes = angular.copy($rootScope.countryTypeCodes);
                    $scope.selectedCounty = $scope.personaddressassoc.countycodesetId;

                    callback();
                });
                
                $scope.$emit('cancel.drawer.event', function(callback, properties) {
                    angular.copy({}, $scope.personaddressassoc);
                    callback();
                });
                
                $scope.$emit('save.drawer.event', function(callback, properties) {
                    
                    var addressForm = document.forms['addressform'];
                    var addressFormElements = addressForm.elements;
                    var addressFields = {};
                    var addressAssocFields = {};
                    var addressCoreFields = {};
                    var ppcm_personid = '';
                    var ppcm_personaddressid = '';
                    var ppcm_address_street = '';
                    var ppcm_address_city = '';
                    var ppcm_addresspriorityorder = '';
                    var newaddress = false;

                    angular.forEach(addressFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[PERSONADDRESS:')) {
                            if(element.name.includes(']CountyCodeSetId')){
                                addressFields[element.name] = $scope.selectedCounty;
                            }
                            else{
                                addressFields[element.name] = element.value;
                            }
                        }
                        if(element.name == 'ppcm_personid'){
                            ppcm_personid = element.value;
                        }
                        if(element.name == 'ppcm_addresspriorityorder'){
                            ppcm_addresspriorityorder = element.value;
                        }
                        if(element.name.includes(']Street')){
                            ppcm_address_street = element.value;
                        }
                        if(element.name.includes(']City')){
                            ppcm_address_city = element.value;
                        }
                    });
                    addressFields['ac'] = "autosendupdate";

                    angular.forEach(addressFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[PERSONADDRESSASSOC')) {
                            addressAssocFields[element.name] = element.value;
                            if (element.name.includes('PersonAddressAssocID') && element.value == '') {
                                newaddress = true;
                            }
                        }
                    });
                    addressAssocFields['ac'] = "autosendupdate";
                    
                    angular.forEach(addressFormElements, function (element, key) {
                        if (element.name.startsWith('CF-[PERSONADDRESSCOREFIELDS')) {
                            if(element.name.includes(']County')){
                                addressCoreFields[element.name] = $scope.selectedCountyFipsCode;
                                // NOTE: I'm just combining the personaddresscorefields fields with the personaddress fields
                                addressFields[element.name] = $scope.selectedCountyFipsCode;
                            }
                            else{
                                addressCoreFields[element.name] = element.value;
                            }
                        }
                    });
                    addressCoreFields['ac'] = "autosendupdate";
                    
                    // NOTE: Make request to add or update the personaddress record
                    $http({
                        method: 'POST',
                        url: 'white.html',
                        data: $j.param(addressFields),
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).then(function (response) {
                        // NOTE: Chain the second request to get the address id of the record we just added or updated
                        return $http({
                            method: 'GET',
                            url: encodeURI('getIdfromStreetCity.json?s='+ppcm_address_street+'&c='+ppcm_address_city),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        }, response.data);
                    }).then(function(response){
                        // NOTE: Chain the third request to add or update the personaddressassoc record
                        if(newaddress){
                            addressAssocFields['CF-[PERSONADDRESSASSOC:-99]PersonAddressID'] = response.data;
                            addressAssocFields['CF-[PERSONADDRESSASSOC:-99]PersonID'] = ppcm_personid;
                            addressAssocFields['CF-[PERSONADDRESSASSOC:-99]AddressPriorityOrder'] = ppcm_addresspriorityorder;
                        }
                        return $http({
                            method: 'POST',
                            url: 'white.html',
                            data: $j.param(addressAssocFields),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        }, response.data);
                    }).finally(function (response) {
                        // NOTE: Clean up and refresh the address list
                        angular.copy({}, $scope.personaddressassoc);
                        $scope.selectedCounty = '';
                        $rootScope.$emit("CallRefreshAddresses", {});
                    });
                    
                    callback();
                });
                
        };
        
        init();

        $scope.$watch('selectedCounty', function(newValue, oldValue) {
            if ((newValue !== oldValue) && (newValue !== '')) {
                let countyName = $scope.countyTypes.find(item => item.codesetId === newValue).displayValue;
                let fipsCode = $scope.countyFipsCodes.find(item => item.countyname === countyName).fipscode;
                $scope.selectedCountyFipsCode = fipsCode;
                
            }
        });

    }); // end address controller

    ppContactApp.controller('removeaddressController', function($scope, $rootScope, $http, $httpParamSerializer){
        $scope.address = {};
        
        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                 $scope.address = angular.copy(properties.data);
                 callback();
             });
             
             $scope.$emit('cancel.drawer.event', function(callback, properties) {
                $scope.address = angular.copy({});
                 callback();
             });
             
             $scope.$emit('save.drawer.event', function(callback, properties) {
                 var postData = {};
                 
                 postData["DD-PERSONADDRESSASSOC.PersonAddressAssocID:" + $scope.address["personaddressassocId"]] = "1";
                 postData["ac"] = "autosendupdate";
                 
                 $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
     
                 $http({
                     method: 'POST',
                     url: 'white.html',
                     data: $j.param(postData),
                     headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                 }).then(function (response) {
                     $rootScope.$emit("CallRefreshAddresses", {});
                 });
                 $scope.address = angular.copy({});
                 callback();
             });
             
        };
        
        init();
    }); // end remove address controller

    ppContactApp.controller('contactController', function($scope, $rootScope, $http, $timeout, $compile, $httpParamSerializer, $window){
    
        $scope.contact = {};
        $scope.contactOriginal = {};
        $scope.contactDemographicsJson = {};
        $scope.codesets = [];

        $scope.newphone = {};
        $scope.newemail = {};
        $scope.newaddress = {};
        
        $scope.textOnlyPattern = /^[a-zA-Z '-]{1,25}$/;
    
        var getCodeSet = function(type){
            let endpoint = 'codeset.json?type='+type;
            let emptycode = {
                "alternatecodeOne": "",
                "aleternatecodeTwo": "",
                "code": "",
                "codesetId": "",
                "codeType": "",
                "description": "",
                "displayValue": "",
                "effectiveEndDate": "",
                "effectiveStartDate": "",
                "reportedValue": "",
                "displayOrder": ""
            };
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                codeset.push(emptycode);
                $scope.codesets[type] = angular.copy(codeset);
            });
        };
    
        var getNextPriorityOrder = function(collection){
            var highestPriority = 0;
            collection.forEach(function(item){
                if(parseInt(item.priorityOrder) > highestPriority){
                    highestPriority = parseInt(item.priorityOrder);
                }
            });
            return highestPriority + 1;
        };
    
        var getContact = function(ipersonid, istudentdcid) {
            let endpoint = 'contact.json?pid='+ipersonid;
            $http.get(endpoint).then( function (response) {
                var contactData = response.data;
                contactData.pop();
                var contact = contactData[0];
                getPhoneNumbers(contact);
                getEmailAddresses(contact);
                getAddresses(contact);
                contact.studentdcid = istudentdcid;
                $scope.contact = contact;
                $scope.newphone.personid = contact.personId;
                $scope.newemail.personid = contact.personId;
                $scope.newaddress.personid = contact.personId;
                $scope.contactOriginal = angular.copy($scope.contact);
                $scope.contactJson = angular.toJson($scope.contact);
                console.log($scope.contact);
                
            }).finally(function(contactData){
                //$scope.contact = contactData[0];
                //$scope.contactOriginal = angular.copy($scope.contact);
                //console.log($scope.contact);
            });
            
        };
    
        var getPhoneNumbers = function(item){
            let endpoint = 'phonenumbers.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var phoneNumbers = response.data;
                phoneNumbers.pop();
                item.phonenumbers = angular.copy(phoneNumbers);
                $scope.newphone.phoneTypeCodeSetId = $scope.codesets['Phone'].find(item => item.code === 'Not Set').codesetId;
                $scope.newphone.PhoneNumberPriorityOrder = getNextPriorityOrder(item.phonenumbers);
            });
        };
    
        var getEmailAddresses = function(item){
            let endpoint = 'emailaddresses.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var emailAddresses = response.data;
                emailAddresses.pop();
                item.emailaddresses = angular.copy(emailAddresses);
                $scope.newemail.emailTypeCodeSetId = $scope.codesets['Email'].find(item => item.code === 'Not Set').codesetId;
                $scope.newemail.EmailAddressPriorityOrder = getNextPriorityOrder(item.emailaddresses);
            });
        };
    
        var getAddresses = function(item){
            let endpoint = 'addresses.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var addresses = response.data;
                addresses.pop();
                item.addresses = angular.copy(addresses);
                $scope.newaddress.addressTypeCodeSetId = $scope.codesets['Address'].find(item => item.code === 'Not Set').codesetId;
                $scope.newaddress.AddressPriorityOrder = getNextPriorityOrder(item.addresses);
            });
        };

        var getSortedPhoneList = function(){
            return _.sortBy($scope.contact.phonenumbers,function(phone){
                return phone.priorityOrder;
            });
        };

        var getSortedEmailList = function(){
            return _.sortBy($scope.contact.emailaddresses,function(email){
                return email.priorityOrder;
            });
        };

        var getSortedAddressList = function(){
            return _.sortBy($scope.contact.addresses,function(address){
                return address.priorityOrder;
            });
        };

        var saveUpdatedOrder = function(phone){
            
            var postData = {};

            return $http({
                method: 'GET',
                url: 'orderphone.html?ppaid=' + phone.personphonenumberassocId + '&pnpo=' + phone.priorityOrder,
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function(response){
                var orderphoneHTML = angular.element(response.data);
                angular.forEach(orderphoneHTML[0], function(value, key) {
                    var currentElement = angular.element(value);
                    postData[currentElement.attr('name')] = currentElement.val();
                    if(currentElement.attr('name').includes(']PhoneNumberPriorityOrder')){
                        postData[currentElement.attr('name')] = phone.priorityOrder;
                    }
                });
                
                return $http({
                    method: 'POST',
                    url: 'white.html',
                    data: $j.param(postData),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                });
                
            });
        };

        var saveUpdatedEmailOrder = function(email){
            var postData = {};

            return $http({
                method: 'GET',
                url: 'orderemail.html?peaid=' + email.emailaddressassocId + '&epo=' + email.priorityOrder,
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function(response){
                var orderemailHTML = angular.element(response.data);
                angular.forEach(orderemailHTML[0], function(value, key) {
                    var currentElement = angular.element(value);
                    postData[currentElement.attr('name')] = currentElement.val();
                    if(currentElement.attr('name').endsWith('EmailAddressPriorityOrder')){
                        postData[currentElement.attr('name')] = email.priorityOrder;
                    }
                });
                
                return $http({
                    method: 'POST',
                    url: 'white.html',
                    data: $j.param(postData),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                });
                
            });
        };

        var saveUpdatedAddressOrder = function(address){
            var postData = {};

            return $http({
                method: 'GET',
                url: 'orderaddress.html?paaid=' + address.personaddressassocId + '&apo=' + address.priorityOrder,
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function(response){
                var orderaddressHTML = angular.element(response.data);
                angular.forEach(orderaddressHTML[0], function(value, key) {
                    var currentElement = angular.element(value);
                    postData[currentElement.attr('name')] = currentElement.val();
                    if(currentElement.attr('name').includes('AddressPriorityOrder')){
                        postData[currentElement.attr('name')] = address.priorityOrder;
                    }
                });
                
                return $http({
                    method: 'POST',
                    url: 'white.html',
                    data: $j.param(postData),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                });
                
            });
        };

        var hideToast = function(){
            console.log('hide toast');
        };
    
        $scope.editInit = function(personid, studentdcid) {
            
            getContact(personid, studentdcid);
            getCodeSet('Prefix');
            getCodeSet('Relationship');
            getCodeSet('Phone');
            getCodeSet('Email');
            getCodeSet('Address');
            getCodeSet('State');
            getCodeSet('Suffix');
            getCodeSet('Gender');
            getCodeSet('Language');
            
        };

        $scope.submitContactDemographics = function($event){
            $event.preventDefault();
            var contactDemographicsFields = {};
            var contactDemographicsForm = document.forms['demographicsform'];
            var contactDemographicsFormElements = contactDemographicsForm.elements;
            angular.forEach(contactDemographicsFormElements, function (element, key) {
                if (element.name.startsWith('CF-[U_PPCM_REQUESTS')) {
                    if (element.name.endsWith(']REQUESTJSON')) {
                        contactDemographicsFields[element.name] = $scope.contactDemographicsJson;
                    }
                    else{
                        contactDemographicsFields[element.name] = element.value;
                    }      
                }
            });
            contactDemographicsFields['ac'] = "autosendupdate";
            $http({
                method: 'POST',
                url: 'white.html',
                data: $j.param(contactDemographicsFields),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function (response) {
                // NOTE: this is where I can show a toast with the 
                // next three lines and stay on the current page or
                // redirect to home.html
                /*
                console.log('show toast');
                $scope.countDown = 8;
                $scope.countTimer();
                */
               $window.location.href = 'home.html';
            })
        };

        $scope.countDown = 8;
        var timer;
        $scope.countTimer = function () {
            var time = $timeout(function () {
                timer = setInterval(function () {
                    if ($scope.countDown > 0) {
                        $scope.countDown--;
                    } else {
                        clearInterval(timer);
                        hideToast();
                    }
                    $scope.$apply();
                }, 1000);
            }, 0);
        }

        $scope.moveUpOrder = function(index){
            if (index === 0){
                return;
            }
            
            var sortedList = getSortedPhoneList();
            console.log('move up');
            console.log(sortedList);
            // Get the target and item above it
            var target = sortedList[index];
            var above = sortedList[index-1];
            var last = sortedList[sortedList.length-1];
            
            // Update the priorityOrder values
            var aboveOrder = parseInt(above.priorityOrder)+1;
            var parkingSpot = parseInt(last.priorityOrder)+1;
            var targetOrder = parseInt(above.priorityOrder);

            above.priorityOrder = parkingSpot;
            target.priorityOrder = targetOrder;
            
            // Save the changes
            saveUpdatedOrder(above).then(function(){
                saveUpdatedOrder(target).then(function(){
                    above.priorityOrder = aboveOrder;
                    saveUpdatedOrder(above).then(function(){
                        $rootScope.$emit("CallRefreshPhoneNumbers", {});
                    })
                })
            });
        };

        $scope.moveDownOrder = function(index){
            if (index === $scope.contact.phonenumbers.length-1){
                return;
            }
            
            var sortedList = getSortedPhoneList();
            console.log('move down');
            console.log(sortedList);
            // Get the target and item below it
            var target = sortedList[index];
            var below = sortedList[index+1];
            var last = sortedList[sortedList.length-1];
    
            // Update the priorityOrder values
            var belowOrder = parseInt(below.priorityOrder)-1;
            var parkingSpot = parseInt(last.priorityOrder)+1;
            var targetOrder = parseInt(below.priorityOrder);

            below.priorityOrder = parkingSpot;
            target.priorityOrder = targetOrder;
    
            // Save the changes
            saveUpdatedOrder(below).then(function(){
                saveUpdatedOrder(target).then(function(){
                    below.priorityOrder = belowOrder;
                    saveUpdatedOrder(below).then(function(){
                        $rootScope.$emit("CallRefreshPhoneNumbers", {});
                    })
                })
            });
        };

        $scope.moveEmailUpOrder = function(index){
            if (index === 0){
                return;
            }
            
            var sortedList = getSortedEmailList();
            
            // Get the target and item above it
            var target = sortedList[index];
            var above = sortedList[index-1];
            var last = sortedList[sortedList.length-1];
            
            // Update the priorityOrder values
            var aboveOrder = parseInt(above.priorityOrder)+1;
            var parkingSpot = parseInt(last.priorityOrder)+1;
            var targetOrder = parseInt(above.priorityOrder);

            above.priorityOrder = parkingSpot;
            target.priorityOrder = targetOrder;
            
            // Save the changes
            saveUpdatedEmailOrder(above).then(function(){
                saveUpdatedEmailOrder(target).then(function(){
                    above.priorityOrder = aboveOrder;
                    saveUpdatedEmailOrder(above).then(function(){
                        $rootScope.$emit("CallRefreshEmailAddresses", {});
                    })
                })
            });
        };

        $scope.moveEmailDownOrder = function(index){
            if (index === $scope.contact.emailaddresses.length-1){
                return;
            }
            
            var sortedList = getSortedEmailList();
            
            // Get the target and item below it
            var target = sortedList[index];
            var below = sortedList[index+1];
            var last = sortedList[sortedList.length-1];
    
            // Update the priorityOrder values
            var belowOrder = parseInt(below.priorityOrder)-1;
            var parkingSpot = parseInt(last.priorityOrder)+1;
            var targetOrder = parseInt(below.priorityOrder);

            below.priorityOrder = parkingSpot;
            target.priorityOrder = targetOrder;
    
            // Save the changes
            saveUpdatedEmailOrder(below).then(function(){
                saveUpdatedEmailOrder(target).then(function(){
                    below.priorityOrder = belowOrder;
                    saveUpdatedEmailOrder(below).then(function(){
                        $rootScope.$emit("CallRefreshEmailAddresses", {});
                    })
                })
            });
        };

        $scope.moveAddressUpOrder = function(index){
            if (index === 0){
                return;
            }
            
            var sortedList = getSortedAddressList();
            
            // Get the target and item above it
            var target = sortedList[index];
            var above = sortedList[index-1];
            var last = sortedList[sortedList.length-1];
            
            // Update the priorityOrder values
            var aboveOrder = parseInt(above.priorityOrder)+1;
            var parkingSpot = parseInt(last.priorityOrder)+1;
            var targetOrder = parseInt(above.priorityOrder);

            above.priorityOrder = parkingSpot;
            target.priorityOrder = targetOrder;
            
            // Save the changes
            saveUpdatedAddressOrder(above).then(function(){
                saveUpdatedAddressOrder(target).then(function(){
                    above.priorityOrder = aboveOrder;
                    saveUpdatedAddressOrder(above).then(function(){
                        $rootScope.$emit("CallRefreshAddresses", {});
                    })
                })
            });
        };

        $scope.moveAddressDownOrder = function(index){
            if (index === $scope.contact.emailaddresses.length-1){
                return;
            }
            
            var sortedList = getSortedAddressList();
            
            // Get the target and item below it
            var target = sortedList[index];
            var below = sortedList[index+1];
            var last = sortedList[sortedList.length-1];
    
            // Update the priorityOrder values
            var belowOrder = parseInt(below.priorityOrder)-1;
            var parkingSpot = parseInt(last.priorityOrder)+1;
            var targetOrder = parseInt(below.priorityOrder);

            below.priorityOrder = parkingSpot;
            target.priorityOrder = targetOrder;
    
            // Save the changes
            saveUpdatedAddressOrder(below).then(function(){
                saveUpdatedAddressOrder(target).then(function(){
                    below.priorityOrder = belowOrder;
                    saveUpdatedAddressOrder(below).then(function(){
                        $rootScope.$emit("CallRefreshAddresses", {});
                    })
                })
            });
        };

        $scope.consolelogContact = function(contact){
            var contactDemographics = angular.copy(contact);
            delete contactDemographics.phonenumbers;
            delete contactDemographics.emailaddresses;
            delete contactDemographics.addresses;
            delete contactDemographics.guardianId;
            delete contactDemographics.hasDataAccess;
            console.log(contactDemographics);
        };
    
        $scope.$watch('contact', function(newValue, oldValue) {
            if (newValue !== oldValue) {
                let contactDemographics = angular.copy(newValue);
                delete contactDemographics.phonenumbers;
                delete contactDemographics.emailaddresses;
                delete contactDemographics.addresses;
                delete contactDemographics.guardianId;
                delete contactDemographics.hasDataAccess;
                $scope.contactDemographicsJson = angular.toJson(contactDemographics);
                $scope.contactJson = angular.toJson($scope.contact);
            }
        }, true); // Enable deep object comparison

        $rootScope.$on("CallRefreshPhoneNumbers", function(){
            getPhoneNumbers($scope.contact);
        });

        $rootScope.$on("CallRefreshEmailAddresses", function(){
            getEmailAddresses($scope.contact);
        });

        $rootScope.$on("CallRefreshAddresses", function(){
            getAddresses($scope.contact);
        });
    
    }); // end contact controller

});