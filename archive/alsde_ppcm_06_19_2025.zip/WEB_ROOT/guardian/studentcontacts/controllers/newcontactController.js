define(['angular', 'components/shared/index'], function (angular) {

    var _ = require('underscore');
    var ppNewContactApp = angular.module('ppNewContactApp', ['powerSchoolModule']).run(function($rootScope, $http) {
        
        
    });

    ppNewContactApp.directive("ppcmStudentSelector", function() {
        return {
            restrict: 'E',
            scope: {
                'contact': '=',
                'studentchoices': '=',
                'mystudents': '=',
                'selectedstudents': '=',
                'index': '='
            },
            templateUrl: 'directives/studentselector.html',
            link: function (scope, element, attrs) {
                scope.mystudentchoices = angular.copy(scope.mystudents);
            }
        };
   });

    ppNewContactApp.filter('selectedstudents', [ function() {
            return function (object, list) {
                var array = [];
                angular.forEach(object, function (student) {
                    if (!list.some(e => e.studentdcid === student.studentdcid)) {
                        array.push(student);
                    }
                });
                return array;
            };
        }]);

    ppNewContactApp.controller('newcontactController', function($scope, $rootScope, $http, $timeout, $compile, $httpParamSerializer, $q, $window){
        
        var requiredCodeSets = [
            'Relationship',
            'Prefix',
            'Suffix',
            'Gender',
            'Language',
            'Phone',
            'Email'
        ];

        $scope.codesets = [];

        var getCodeSet = function(type){
            let endpoint = 'codeset.json?type='+type;
            let emptycode = {
                "alternatecodeOne": "",
                "aleternatecodeTwo": "",
                "code": "",
                "codesetId": "",
                "codeType": "",
                "description": "",
                "displayValue": "",
                "effectiveEndDate": "",
                "effectiveStartDate": "",
                "reportedValue": "",
                "displayOrder": ""
            };
            return $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                codeset.push(emptycode);
                $scope.codesets[type] = angular.copy(codeset);
            });
        };

        var loadCodeSets = function(){
            return new Promise((resolve, reject) => {
                var promises = [];
                requiredCodeSets.forEach(function(item){
                    promises.push(getCodeSet(item));
                });
                $q.all(promises).then(function(){
                    // NOTE: success
                    resolve(true)
                }).catch(function(response){
                    // NOTE: catch error
                    reject(true);
                });
            });
        };

        $scope.mystudents = [];
        $scope.selectedstudents = [];
        $scope.newcontactJson = {};
        $scope.displayDebugInfo = false;

        $scope.contact = {
            "personId": "",
            "nameFirst": "",
            "nameMiddle": "",
            "nameLast": "",
            "prefixcodesetId": "",
            "suffixcodesetId": "",
            "gendercodesetId": "",
            "languagecodesetId": "",
            "dob": "",
            "raceValue": "",
            "employer": "",
            "primaryemail": "",
            "primaryemailtypecodesetId": "",
            "preferredphonenumber": "",
            "preferredphoneextension": "",
            "preferredphoneissms": "",
            "preferredphonenumbertypecodesetId": "",
            "studentrelationships": []
        };

        var getMyStudents = function(studentDcid){
            let endpoint = 'mystudents.json'
            return $http.get(endpoint).then( function (response) {
                var students = response.data;
                students.pop();
                students.forEach(function(student){
                    $scope.contact.studentrelationships.push(
                        {
                            "relationtypecodesetId": "",
                            "studentdcid": student.studentdcid.toString(),
                            "lastfirst": student.lastfirst,
                            "managecontacts": (student.managecontacts == 0) ? false : true,
                            "selected": (studentDcid == student.studentdcid) ? true : false,
                            "readonly": (studentDcid == student.studentdcid) ? true : false
                        }
                    );
                });
                $scope.mystudents = students;
            });
        };

        $scope.readonlycheck = function(index, readonly){
            if(readonly){
                $scope.contact.studentrelationships[index].selected = true;
            }
        };

        $scope.newcontactInit = function(studentDcid){
            
            /*
            requiredCodeSets.forEach(function(codeSet){
                $scope.codesets[codeSet] = angular.copy($rootScope.codesets[codeSet]);
            });
            */
            loadCodeSets().then(function(){
                $scope.contact.personId = "-1";
                $scope.contact.primaryemailtypecodesetId = $scope.codesets['Email'].find(item => item.code === 'Not Set').codesetId;
                $scope.contact.preferredphonenumbertypecodesetId = $scope.codesets['Phone'].find(item => item.code === 'Not Set').codesetId;
                //$scope.contact.studentrelationships[0].studentdcid = studentDcid.toString();
                getMyStudents(studentDcid).then(function(){
                    
                });
                
            });
            
        };

        $scope.addRelatedStudent = function(){
            //$scope.contact.studentrelationships.push({"relationtypecodesetId": "","studentdcid": ""});
        };

        $scope.removeRelatedStudent = function(index){
            //$scope.contact.studentrelationships.splice(index,1);
        };

        $scope.checkStudentCount = function(){
            if($scope.contact.studentrelationships.length < $scope.mystudents.length){
                return false;
            }
            else{
                return true;
            }
        };

        $scope.submitNewContact = function($event){
            $event.preventDefault();
            // NOTE: Remove students who are not selected
            let selectedstudents = [];
            srindex = $scope.contact.studentrelationships.length - 1;

            while (srindex >= 0) {
                if ($scope.contact.studentrelationships[srindex].selected) {
                    selectedstudents.push($scope.contact.studentrelationships[srindex]);
                }
                srindex -= 1;
            }
            //return false;
            $scope.contact.studentrelationships = angular.copy(selectedstudents);
            var newcontactFields = {};
            var newContactForm = document.forms['newcontactform'];
            var newContactFormElements = newContactForm.elements;
            angular.forEach(newContactFormElements, function (element, key) {
                if (element.name.startsWith('CF-[U_PPCM_REQUESTS')) {
                    if (element.name.includes(']REQUESTJSON')) {
                        newcontactFields[element.name] = $scope.newcontactJson;
                    }
                    else{
                        newcontactFields[element.name] = element.value;
                    }      
                }
            });
            newcontactFields['ac'] = "autosendupdate";
            $http({
                method: 'POST',
                url: 'white.html',
                data: $j.param(newcontactFields),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function (response) {
                $window.location.href = 'home.html';
            })
        };

        $scope.consolelogContact = function(contact){
            var newcontact = angular.copy(contact);
            console.log(newcontact);
        };

        $scope.$watch('contact', function(newValue, oldValue) {
            if (newValue !== oldValue) {
                let newcontact = angular.copy(newValue);
                //$scope.selectedstudents = angular.copy($scope.contact.studentrelationships);
                $scope.newcontactJson = angular.toJson(newcontact);
            }
        }, true);

    });

});