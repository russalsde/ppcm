define(['angular', 'components/shared/index'], function (angular) {

    var ppcmRequestAlert = angular.module('ppcmRequestAlert', ['powerSchoolModule']);

    // START: Start Page Alert Controller (alertController)
    ppcmRequestAlert.controller('alertController', function($scope, $rootScope, $http, $window, $httpParamSerializer){

        $scope.requestCount = 0;
        
        var getRequestCount = function(){
            let endpoint = '/admin/ppcm/json/requestcount.json';
            $http.get(endpoint).then( function (response) {
                var requestCount = response.data;
                requestCount.pop();
                $scope.requestCount = requestCount[0].requestCount;
            });
        };

        getRequestCount();

    }); // END: Start Page Alert Controller (alertController)

    // START: App Module (ppContactsApp)
    var ppContactsApp = angular.module('ppContactsApp', ['powerSchoolModule']).run(function($rootScope, $http) {
        
        var getRelationshipCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Relationship';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.relationshipCodes = angular.copy(codeset);
            });
        };

        var getPhoneTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Phone';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.phoneTypeCodes = angular.copy(codeset);
            });
        }; 

        var getEmailTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Email';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.emailTypeCodes = angular.copy(codeset);
            });
        }; 

        var getAddressTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Address';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.addressTypeCodes = angular.copy(codeset);
            });
        }; 

        var getStateTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=State';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.stateTypeCodes = angular.copy(codeset);
            });
        }; 

        var getPrefixTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Prefix';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.prefixTypeCodes = angular.copy(codeset);
            });
        };

        var getSuffixTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Suffix';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.suffixTypeCodes = angular.copy(codeset);
            });
        };

        var getGenderTypeCodes = function(){
            let endpoint = '/admin/ppcm/json/codeset.json?type=Gender';
            $http.get(endpoint).then( function (response) {
                let codeset = response.data;
                codeset.pop();
                $rootScope.genderTypeCodes = angular.copy(codeset);
            });
        };

        getRelationshipCodes();
        getPhoneTypeCodes();
        getEmailTypeCodes();
        getAddressTypeCodes();
        getStateTypeCodes();
        getPrefixTypeCodes();
        getSuffixTypeCodes();
        getGenderTypeCodes();

    });// END: App Module (ppContactsApp)

    // START: Change Request Directive (ppcmChangeRequest)
    ppContactsApp.directive("ppcmChangeRequest", function() {
            return {
                restrict: 'E',
                scope: {
                    'changeRequest': '=',
                    'index': '='
                },
                templateUrl: 'templates/changerequest.html',
                link: function (scope, element, attrs) {
                    // code here
                }
            };
    });// END: Change Request Directive (ppcmChangeRequest)

    // START: Person Directive (ppcmPerson)
    ppContactsApp.directive("ppcmPerson", function() {
            return {
                restrict: 'E',
                scope: {
                    'person': '='
                },
                templateUrl: 'templates/person.html',
                link: function (scope, element, attrs) {
                    // code here
                }
            };
    });// END: Person Directive (ppcmPerson)
    
    // START: Add Contact Request Directive (ppcmAddRequest)
    ppContactsApp.directive("ppcmAddRequest", function() {
    return {
        restrict: 'E',
        scope: {
            'addRequest': '=',
            'index': '='
        },
        templateUrl: 'templates/newcontact.html',
        link: function (scope, element, attrs) {
            // code here
        }
    };
    });// END: Add Contact Request Directive (ppcmAddRequest)

    // START: Main Application Controller (appController)
    ppContactsApp.controller('appController', function($scope, $rootScope, $http, $window, $httpParamSerializer, $q){

        var requiredCodeSets = [
            'Relationship',
            'Prefix',
            'Suffix',
            'Gender',
            'Language',
            'Phone',
            'Email',
            'Address'
        ];

        $scope.codesets = [];

        var getCodeSet = function(type){
            let endpoint = '/admin/ppcm/json/codeset.json?type='+type;
            let emptycode = {
                "alternatecodeOne": "",
                "aleternatecodeTwo": "",
                "code": "",
                "codesetId": "",
                "codeType": "",
                "description": "",
                "displayValue": "",
                "effectiveEndDate": "",
                "effectiveStartDate": "",
                "reportedValue": "",
                "displayOrder": ""
            };
            return $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                codeset.push(emptycode);
                $scope.codesets[type] = angular.copy(codeset);
            });
        };

        var loadCodeSets = function(){
            return new Promise((resolve, reject) => {
                var promises = [];
                requiredCodeSets.forEach(function(item){
                    promises.push(getCodeSet(item));
                });
                $q.all(promises).then(function(){
                    // NOTE: success
                    resolve(true)
                }).catch(function(response){
                    // NOTE: catch error
                    reject(true);
                });
            });
        };

        
        // Selected requests
        $scope.requestSelection = [];

        // Toggle selection for a given request by requestId
        $scope.toggleSelection = function toggleSelection(requestId) {
            
            var idx = $scope.requestSelection.indexOf(requestId);

            // Is currently selected
            if (idx > -1) {
                $scope.requestSelection.splice(idx, 1);
            }
            // Is newly selected
            else {
                $scope.requestSelection.push(requestId);
            }
        };

        $scope.toggleAllRequests = function() {
            $scope.requestSelection = [];
            if($scope.toggleSelected){
                $scope.toggleSelected = false;
            }
            else {
                $scope.changeRequests.forEach(markSelected);
                $scope.toggleSelected = true;
            }
        };

        var markSelected = function(item){
            $scope.requestSelection.push(item.requestId);
        };


        $rootScope.$on("CallRefreshRequests", function(){
            $scope.refreshRequests();
        });

        $rootScope.$on("SaveApproveChangeRequest", function(event, changeRequest){
            $scope.saveChangeRequest(changeRequest).then(function(savedChangeRequest){
                $scope.approveChangeRequest(savedChangeRequest);
            });
        });

        $rootScope.$on("SaveChangeRequest", function(event, changeRequest){
            $scope.saveChangeRequest(changeRequest).then(function(){
                getChangeRequests();
            });
        });

        $rootScope.$on("CompleteNewContactRequest", function(event, addRequest){
            $scope.updateStatus(addRequest.requestId,"completed","add").then(function(){
                getAddRequests();
            });
        });

        $scope.refreshRequests = function() {
            getChangeRequests();
        };

        $scope.saveChangeRequest = function(changeRequest){
            return new Promise((resolve, reject) => {
                
                var tableData = Object.assign({}, changeRequest);

                tableData.emailtypecodesetId = getCodesetId("Email",tableData.emailtypeCode);
                tableData.phonetypecodesetId = getCodesetId("Phone",tableData.phonetypeCode);
                tableData.addresstypecodesetId = getCodesetId("Address",tableData.addresstypeCode);

                // NOTE: remove object properties not stored in the extension table
                delete tableData.person;
                delete tableData.requestId;
                delete tableData.requestedbyId;
                delete tableData.requestedbyfirstname;
                delete tableData.requestedbylastname;
                delete tableData.requestedwhen;
                delete tableData.statecodesetCode;
                delete tableData.emailtype;
                delete tableData.emailtypeCode;
                delete tableData.phonetype;
                delete tableData.phonetypeCode;
                delete tableData.addresstype;
                delete tableData.addresstypeCode;

                // NOTE: add back object properties that need to be stored
                tableData.requestedby = changeRequest.requestedbyId;
            
                var endpoint = '/ws/schema/table/U_PPCM_REQUESTS/' + changeRequest.requestId;
                var request = {
                    "id": changeRequest.requestId,
                    "name": "U_PPCM_REQUESTS",
                    "tables": {
                        "U_PPCM_REQUESTS": tableData
                    }
                };

                $http.put(endpoint,request).then(function onSuccess(response) {
                    resolve(changeRequest);
                }).catch(function onError(response){
                    reject(true);
                });
            });
        };

        $scope.approveChangeRequest = function(changeRequest){
            approveChanges(changeRequest).then(function(){
                setStatus(changeRequest.requestId,"completed");
            });
        };

        var approveChanges = function(changeRequest) {
            
            // NOTE: asynchronous queue method - faster
            return new Promise((resolve, reject) => {
                
                var promisesArray = [];
                let prefixCodesetCode = getCodesetCode("Prefix",changeRequest.update.prefixcodesetId);
                let suffixCodesetCode = getCodesetCode("Suffix",changeRequest.update.suffixcodesetId);
                let genderCodesetCode = getCodesetCode("Gender",changeRequest.update.gendercodesetId);

                let updatedDemographics = {
                    "contactId": changeRequest.update.personId,
                    "firstName": changeRequest.update.nameFirst,
                    "middleName": changeRequest.update.nameMiddle,
                    "lastName": changeRequest.update.nameLast,
                    "prefix": prefixCodesetCode,
                    "suffix": suffixCodesetCode,
                    "gender": genderCodesetCode,
                    "employer": changeRequest.update.employer,
                    "_extension_data":{"_table_extension":[
                        {"name":"personcorefields","_field":[
                            {"name":"dob","value":formatDate(changeRequest.update.dob)},
                            {"name":"race","value":changeRequest.update.raceValue}
                        ]}
                    ]}
                };

                let updateNameInfo = $http.put('/ws/contacts/' + changeRequest.personId + '/demographics',updatedDemographics);
                promisesArray.push(updateNameInfo);

                $q.all(promisesArray).then(function(){
                    // NOTE: success
                    resolve(true)
                }).catch(function(response){
                    // NOTE: catch error
                    reject(true);
                });

            });
        };

        var setStatus = function(changeRequestId, status){

            var endpoint = '/ws/schema/table/U_PPCM_REQUESTS/' + changeRequestId;
            var request = {
                "id": changeRequestId,
                "name": "U_PPCM_REQUESTS",
                "tables": {
                    "U_PPCM_REQUESTS": {}
                }
            };
            request.tables["U_PPCM_REQUESTS"][status] = "1";

            $http.put(endpoint,request).then( function (response) {
                getAddRequests();
                getChangeRequests();
            });

        };

        $scope.updateStatus = function(changeRequestId, status, requestType){

            var endpoint = '/ws/schema/table/U_PPCM_REQUESTS/' + changeRequestId;
            var request = {
                "id": changeRequestId,
                "name": "U_PPCM_REQUESTS",
                "tables": {
                    "U_PPCM_REQUESTS": {}
                }
            };
            request.tables["U_PPCM_REQUESTS"][status] = "1";

            return $http.put(endpoint,request).then( function (response) {
                if(requestType == 'update'){getChangeRequests();};
                if(requestType == 'add'){getAddRequests();};
            });

        };

        var getCodesetId = function(codetype, code){
            return $scope.codesets[codetype].find(item => item.code == code).codesetId;
        };

        var getCodesetCode = function(codetype, codesetId){
            return $scope.codesets[codetype].find(item => item.codesetId == codesetId).code;
        };

        var getCodesetDisplayValue = function(codetype, codesetId){
            return $scope.codesets[codetype].find(item => item.codesetId == codesetId).displayValue;
        };

        var formatDate = function(dateString){
            if(dateString == null || dateString == undefined || dateString == ''){
                return '';
            }
            let date = new Date(dateString);
            let month = date.getMonth() + 1; // Months are zero based
            let day = date.getDate();
            let year = date.getFullYear();
            return year + '-' + month + '-' + day;
        };

        var formatDateForDisplay = function(dateString){
            if(dateString == null || dateString == undefined || dateString == ''){
                return '';
            }
            let date = new Date(dateString);
            let month = date.getMonth() + 1; // Months are zero based
            let day = date.getDate();
            let year = date.getFullYear();
            return month + '/' + day + '/' + year;
        };

        var deleteChangeRequest = function(requestId){

            // NOTE: Soft delete ;)
            setStatus(requestId,"deleted");

            // NOTE: Old, hard delete method
            /*
            $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
            $http({
                method: 'DELETE',
                url: '/ws/schema/table/U_PPCM_REQUESTS/' + requestId,
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).success(function (data, status, headers, config) {
                $scope.refreshRequests();
            }).error(function (data, status, headers, config) {
                // error handling here
            });
            */

        };

        $scope.addRequests = [];
        $scope.changeRequests = [];
        $scope.uniquePersons = [];
        $scope.toggleSelected = false;

        var startApp = function(){
            loadCodeSets().then(function(){
                getAddRequests();
                getChangeRequests();
            });
        };

        var getAddRequests = function(){
            let endpoint = 'json/requests.json?type=add';
            $http.get(endpoint).then( function (response) {
                let addRequests = response.data;
                addRequests.pop();
                addRequests.forEach(getNewContactFromJson);
                $scope.addRequests = angular.copy(addRequests);
            }).then(function(){
                $scope.addRequests.forEach(getAssociatedStudent);
            }).then(function(){
                console.log('Add Requests:');
                console.log($scope.addRequests);
            });
        };

        var getChangeRequests = function(){
            let endpoint = 'json/requests.json?type=update';
            $http.get(endpoint).then( function (response) {
                let changeRequests = response.data;
                changeRequests.pop();
                changeRequests.forEach(getCurrent);
                changeRequests.forEach(getUpdateRequestFromJson);
                $scope.changeRequests = angular.copy(changeRequests);
            }).then(function(){
                let uniquePeople = getUniquePersons($scope.changeRequests);
                uniquePeople.forEach(getDetails);
                $scope.uniquePersons = uniquePeople;
            });
        };

        var getUniquePersons = function(requests){
            var unique = [];
            var distinct = [];
            for( let i = 0; i < requests.length; i++ ){
                if( !unique[requests[i].personId]){
                    distinct.push({'personId':requests[i].personId, 'requests':[requests[i].requestId]});
                    unique[requests[i].personId] = 1;
                }
                else{
                    distinct[distinct.length - 1].requests.push(requests[i].requestId);
                }
            }
            return distinct;
        };

        var getUpdateRequestFromJson = function(item){
            item.update = angular.fromJson(item.requestJson);
            item.update.prefix = getCodesetCode("Prefix",item.update.prefixcodesetId);
            item.update.suffix = getCodesetCode("Suffix",item.update.suffixcodesetId);
            item.update.gender = getCodesetCode("Gender",item.update.gendercodesetId);
            item.update.displayDOB = formatDateForDisplay(item.update.dob);
        };

        var getNewContactFromJson = function(item){
            item.newcontact = angular.fromJson(item.requestJson);
            item.newcontact.prefix = getCodesetCode("Prefix",item.newcontact.prefixcodesetId);
            item.newcontact.suffix = getCodesetCode("Suffix",item.newcontact.suffixcodesetId);
            item.newcontact.primaryemailtype = getCodesetDisplayValue("Email",item.newcontact.primaryemailtypecodesetId);
            item.newcontact.preferredphonenumbertype = getCodesetDisplayValue("Phone",item.newcontact.preferredphonenumbertypecodesetId);
            item.newcontact.primaryemailtypecode = getCodesetCode("Email",item.newcontact.primaryemailtypecodesetId);
            item.newcontact.preferredphonenumbertypecode = getCodesetCode("Phone",item.newcontact.preferredphonenumbertypecodesetId);
        };

        var getCurrent = function(item){
            let endpoint = 'json/person.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var person = response.data;
                person.pop();
                item.current = person[0];    
            });
        };

        var getDetails = function(item){
            let endpoint = 'json/person.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                let persons = angular.copy(response.data);
                persons.pop();
                let person = persons[0];
                
                person.prefix = getCodesetCode("Prefix",person.prefixcodesetid);
                person.suffix = getCodesetCode("Suffix",person.suffixcodesetid);
                person.gender = getCodesetCode("Gender",person.gendercodesetid);
                person.displayDOB = formatDateForDisplay(person.dob);
                item.demographics = person;
            });
        };

        var getEmailAddresses = function(item){
            let endpoint = 'json/emailaddresses.json?personid='+item.personId;
            return $http.get(endpoint).then( function (response) {
                let emailAddresses = response.data;
                emailAddresses.pop();
                item.emailaddresses = angular.copy(emailAddresses);
                if(emailAddresses.length > 0){
                    item.primaryEmailAddress = emailAddresses.find(item => item.isPrimary === '1');
                }
                    
            });
        };

        var getPhoneNumbers = function(item){
            let endpoint = 'json/phonenumbers.json?personid='+item.personId;
            return $http.get(endpoint).then( function (response) {
                let phoneNumbers = response.data;
                phoneNumbers.pop();
                item.phonenumbers = angular.copy(phoneNumbers);
                if(phoneNumbers.length > 0){
                    item.primaryPhoneNumber = angular.copy(phoneNumbers[0]);
                    for(var j = 0; j < phoneNumbers.length; j++){
                        if (phoneNumbers[j].isPreferred === '1') { item.primaryPhoneNumber = phoneNumbers[j]; break; }
                    }
                }
            });
        };

        var getAddresses = function(item){
            let endpoint = 'json/addresses.json?personid='+item.personId;
            return $http.get(endpoint).then( function (response) {
                let addresses = response.data;
                addresses.pop();
                item.addresses = angular.copy(addresses);
                if(addresses.length > 0){
                    item.primaryAddress = angular.copy(addresses[0]);
                }
            });
        };

        var getAssociatedStudent = function(item){
            let endpoint = 'json/student.json?dcid='+item.newcontact.studentdcid;
            $http.get(endpoint).then( function (response) {
                let students = response.data;
                students.pop();
                let student = students[0];
                item.newcontact.associatedstudent = student;
            });
        };

        startApp();

        $scope.addContact = function(changeRequest){
        // code here
        };

        $scope.addStudentContactsDialog = function() {
            // code here
        };

        $scope.confirmDeleteRequest = function(changeRequest){
            deleteChangeRequest(changeRequest.requestId);
        };
        
        $scope.confirmDeleteNewContactRequest = function(addRequest){
            deleteChangeRequest(addRequest.requestId);
        };
        
        $scope.cancelDeleteRequest = function(){
            // code here
        };

        $scope.confirmDeleteSelectedRequests = function(){
            $scope.requestSelection.forEach(deleteChangeRequest);
        };

        $scope.cancelDeleteSelectedRequests = function(){
            // code here
        };

        $scope.confirmApproveSelectedRequests = function(){
            
            // NOTE: sort the change requests by requestId ascending (oldest to newest)
            $scope.changeRequests.sort((a, b) => a.requestId - b.requestId);

            // NOTE: no way to observe when forEach is done, we need this so we can refresh the requests
            //$scope.changeRequests.forEach(approveIfSelected);

            const changeRequestPromises = $scope.changeRequests.map(changeRequest => approveIfSelected(changeRequest));
            Promise.all(changeRequestPromises).then(arrayOfResponses => {
                getChangeRequests();
            });

        };

        $scope.cancelApproveSelectedRequests = function(){
            // code here
        };

        $scope.aSelectedPersonHasMultipleRequests = function(){
            $scope.someoneHasMultipleRequests = false;
            if($scope.requestSelection.length > 0){
                $scope.uniquePersons.forEach(checkForMultipleRequests);
            }
            return $scope.someoneHasMultipleRequests;
        };

        var approveIfSelected = function(changeRequest){
            if($scope.requestSelection[$scope.requestSelection.indexOf(changeRequest.requestId)] > -1){
                approveChanges(changeRequest).then(function(){
                    setStatus(changeRequest.requestId,"completed");
                });
            }
        };
        
        var checkForMultipleRequests = function(person){
            var personIsSelected = false;
            if(person.requests.length > 0){
                for(var k=0; k < person.requests.length; k++){
                    if($scope.requestSelection[$scope.requestSelection.indexOf(person.requests[k])] == person.requests[k]){
                        personIsSelected = true;
                        break;
                    }
                }
            }
            if((person.requests.length > 1) && personIsSelected){
                $scope.someoneHasMultipleRequests = true;
            }
        };
       
    }); // END: Main Application Controller (appController)

    // START: Edit Change Request Controller (editController)
    ppContactsApp.controller('editController', function($scope, $rootScope, $http, $window, $httpParamSerializer){

        $scope.request = {};
       
        var init = function() {
           
            $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.changerequest = angular.copy(properties.data);
                $scope.emailTypeCodes = angular.copy($rootScope.emailTypeCodes);
                $scope.phoneTypeCodes = angular.copy($rootScope.phoneTypeCodes);
                $scope.addressTypeCodes = angular.copy($rootScope.addressTypeCodes);
                $scope.stateTypeCodes = angular.copy($rootScope.stateTypeCodes);
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                callback();
            });
            
            $scope.$emit('save.drawer.event', function(callback, properties) {
                $rootScope.$emit("SaveChangeRequest", $scope.changerequest);
                callback();
            });

            $scope.$emit('saveapprove.drawer.event', function(callback, properties) {
                $rootScope.$emit("SaveApproveChangeRequest", $scope.changerequest);
                callback();
            });

        };
       
        init();

    }); // END: Edit Change Request Controller (editController)

    // START: Edit New Contact Request Controller (editnewcontactController)
    ppContactsApp.controller('editnewcontactController', function($scope, $rootScope, $http, $window, $httpParamSerializer ){
        $scope.request = {};
       
        var init = function() {
           
            $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.changerequest = angular.copy(properties.data);
                $scope.emailTypeCodes = angular.copy($rootScope.emailTypeCodes);
                $scope.phoneTypeCodes = angular.copy($rootScope.phoneTypeCodes);
                $scope.addressTypeCodes = angular.copy($rootScope.addressTypeCodes);
                $scope.stateTypeCodes = angular.copy($rootScope.stateTypeCodes);
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                callback();
            });
            
            $scope.$emit('save.drawer.event', function(callback, properties) {
                $rootScope.$emit("SaveChangeRequest", $scope.changerequest);
                callback();
            });

            $scope.$emit('saveapprove.drawer.event', function(callback, properties) {
                $rootScope.$emit("SaveApproveChangeRequest", $scope.changerequest);
                callback();
            });

        };
       
        init();

    }); // END: Edit New Contact Request Controller (editnewcontactController)

    // START: Contact Search Controller (contactSearchController)
    ppContactsApp.controller('contactSearchController', function($scope, $rootScope, $http, $window, $httpParamSerializer, $q, $timeout){
        $scope.newcontact = {};
        $scope.searchResults = [];
        $scope.selectedContact = {};
        $scope.selectedContact.personId = 0;
        $scope.showFeedbackMessage = false;
        $scope.feedbackMessage = '';
        $scope.showConfirmationMessage = false;
        $scope.confirmationMessage = '';
        $scope.createNewConfirmed = false;

        var init = function() {
           
            $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.addrequest = angular.copy(properties.data);
                $scope.newcontact = angular.copy(properties.data.newcontact);
                $scope.searchForContacts($scope.newcontact);
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                /*
                $scope.newcontact = {};
                $scope.searchResults = [];
                $scope.selectedContact = {};
                $scope.selectedContact.personId = 0;
                $scope.showFeedbackMessage = false;
                $scope.feedbackMessage = '';
                $scope.showConfirmationMessage = false;
                $scope.confirmationMessage = '';
                $scope.createNewConfirmed = false;
                */
                resetDrawer();
                callback();
            });
            
            $scope.$emit('useExistingContact.drawer.event', function(callback, properties) {
                if($scope.selectedContact.personId){
                    useExistingContact($scope.addrequest, $scope.selectedContact.personId);
                    resetDrawer();
                    callback();
                }
                else{
                    $scope.showFeedback('To Select and Associate you must select a contact.');
                    callback(false);
                }
                
            });

            $scope.$emit('createNewContact.drawer.event', function(callback, properties) {
                if($scope.selectedContact.personId && !$scope.createNewConfirmed){
                    $scope.showConfirmation('You selected an existing contact but chose to Create New Contact. Do you want to continue?');
                    callback(false);
                }
                else{
                    createNewContact($scope.newcontact).then(function(){
                        $rootScope.$emit("CompleteNewContactRequest", $scope.addrequest);
                        resetDrawer();
                        callback();
                    });
                }
            });

        };
       
        init();

        var resetDrawer = function(){
            $scope.newcontact = {};
            $scope.searchResults = [];
            $scope.selectedContact = {};
            $scope.selectedContact.personId = 0;
            $scope.showFeedbackMessage = false;
            $scope.feedbackMessage = '';
            $scope.showConfirmationMessage = false;
            $scope.confirmationMessage = '';
            $scope.createNewConfirmed = false;
        };

        $scope.showFeedback = function(message){
            $scope.feedbackMessage = message;
            $scope.showFeedbackMessage = true;
            $scope.$apply();
            $timeout(function() {
                $scope.showFeedbackMessage = false;
                $scope.$apply();
            }, 5000);
        };

        $scope.showConfirmation = function(message){
            $scope.confirmationMessage = message;
            $scope.showConfirmationMessage = true;
            $scope.$apply();
        };

        $scope.confirmCreateNewContact = function(){
            $scope.createNewConfirmed = true;
            var button = document.getElementById('btnCreateNewContact');
            if (button) {
                button.click();
            }
        };

        $scope.cancelCreateNewContact = function(){
            $scope.confirmationMessage = '';
            $scope.showConfirmationMessage = false;
        };

        var getRelationshipCodeFromId = function(relationshipCodesetId){
            let relationshipCodesetCode = $rootScope.relationshipCodes.find(item => item.codesetId == relationshipCodesetId).code;
            return relationshipCodesetCode;
        };

        var getStudentNumberFromDcid = function(studentdcid){
            let endpoint = 'json/student.json?dcid='+studentdcid;
            $http.get(endpoint).then( function (response) {
                let students = response.data;
                students.pop();
                let student = students[0];
                return student.studentnumber;
            });
        };

        var useExistingContact = function(addRequest, existingContactId){
            setContactAsActive(existingContactId).then(function(){
                let associationPromises = [];
                addRequest.newcontact.studentrelationships.forEach(function(relationship){
                    if(relationship.selected){
                        checkForExistingAssociation(existingContactId, relationship.studentdcid).then(function(associationExists){
                            if(!associationExists){
                                let relationshipCode = getRelationshipCodeFromId(relationship.relationtypecodesetId);
                                let studentNumber = getStudentNumberFromDcid(relationship.studentdcid);
                                associationPromises.push(createStudentContactAssociation(existingContactId,relationshipCode,studentNumber,relationship.studentdcid));
                            }
                        });
                    }
                    $q.all(associationPromises).then(function(){
                        $rootScope.$emit("CompleteNewContactRequest", $scope.addrequest);
                    });
                });
            });
        };

        var setContactAsActive = function(personId){
            let endpoint = '/ws/contacts/contact/'+personId;
            return $http.get(endpoint).then( function (response) {
                let existingContact = response.data;
                existingContact.active = true;
                return existingContact;
            }).then((existingContact) => {
                let endpoint = '/ws/contacts/'+existingContact.contactId;
                let contactUpdate = {
                    "contactId": existingContact.contactId,
                    "active":true,
                    "phones": existingContact.phones
                };
                $http.post(endpoint,contactUpdate).then( function (response) {
                    let updatedContact = response.data;
                });
            });
        };

        var checkForExistingAssociation = function(personId, studentDcid){
            
            let endpoint = '/ws/contacts/'+personId+'/students';
            return $http.get(endpoint).then( function (response) {
                let contactStudents = response.data;
                let associationExists = contactStudents.find(student => student.dcid == studentDcid);
                if(associationExists){
                    return true;
                }
                else{
                    return false;
                }
            });
        };

        var createStudentContactAssociation = function(personId, relationshipCode, studentNumber, studentDcid){
            let studentContactAssocObj = {
                "studentNumber": studentNumber,
                "dcid": studentDcid,
                "studentDetails":[{
                    "relationship": relationshipCode
                }]
            };
            let endpoint = '/ws/contacts/'+personId+'/students';
            return $http.post(endpoint, studentContactAssocObj).then( function (response) {
                let createResponse = response.data;
            });
        };

        var createNewContact = function(contact){
            let endpoint = '/ws/contacts/contactfull';
            let contactEmail = [{
                    "contactEmailId": null,
                    "emailId": null,
                    "deleted": false,
                    "primary": true,
                    "type": contact.primaryemailtypecode,
                    "address": contact.primaryemail
            }];
            let contactStudents = [];
            contact.studentrelationships.forEach(function(student){
                if(student.selected){
                    let relationshipCode = getRelationshipCodeFromId(student.relationtypecodesetId);
                    contactStudents.push(
                        {
                            "dcid": Number(student.studentdcid),
                            "canAccessData": false,
                            "studentDetails": [
                                {
                                    "relationship": relationshipCode,
                                    "relationshipNote": "",
                                    "emergency": false,
                                    "custodial": false,
                                    "livesWith": false,
                                    "schoolPickup": false,
                                    "receivesMail": false,
                                    "excludeFromStateReporting": false,
                                    "deleted": false,
                                    "active": true,
                                    "generalCommunicationFlag": false,
                                    "confidentialCommunicationFlag": false
                                }
                            ],
                            "originalContactType": null,
                            "schoolAbbr": null,
                            "schoolNumber": null,
                            "studentNumber": null
                        }
                    );
                }
            });
            let contactObj = {
                "contactId": null,
                "firstName": contact.nameFirst,
                "middleName": contact.nameMiddle,
                "lastName": contact.nameLast,
                "prefix": contact.prefix,
                "suffix": contact.suffix,
                "gender": null,
                "contactNumber": null,
                "stateContactNumber": null,
                "stateExcludeFromReporting": false,
                "active": true,
                "phones": [
                    {
                        "contactsPhoneId": null,
                        "phoneNumberId": null,
                        "deleted": false,
                        "sequence": 1,
                        "preferred": true,
                        "phoneType": contact.preferredphonenumbertypecode,
                        "phoneNumber": contact.preferredphonenumber,
                        "extension": null,
                        "sms": (contact.preferredphoneissms === "1") ? true : false
                    }
                ],
                "contactAccount": null,
                "contactStudents": contactStudents,
                "employer": null
            };
            if(contact.primaryemail.length){
                contactObj.emails = contactEmail;
            }
            return $http.post(endpoint, contactObj).then( function (response) {
                let createResponse = response.data;
            });
        };

        var getEmailAddresses = function(item){
            let endpoint = 'json/emailaddresses.json?personid='+item.personId;
            return $http.get(endpoint).then( function (response) {
                let emailAddresses = response.data;
                emailAddresses.pop();
                item.emailaddresses = angular.copy(emailAddresses);
                if(emailAddresses.length > 0){
                    item.primaryEmailAddress = emailAddresses.find(item => item.isPrimary === '1');
                }
                    
            });
        };

        var getPhoneNumbers = function(item){
            let endpoint = 'json/phonenumbers.json?personid='+item.personId;
            return $http.get(endpoint).then( function (response) {
                let phoneNumbers = response.data;
                phoneNumbers.pop();
                item.phonenumbers = angular.copy(phoneNumbers);
                if(phoneNumbers.length > 0){
                    item.primaryPhoneNumber = angular.copy(phoneNumbers[0]);
                    for(var j = 0; j < phoneNumbers.length; j++){
                        if (phoneNumbers[j].isPreferred === '1') { item.primaryPhoneNumber = phoneNumbers[j]; break; }
                    }
                }
            });
        };

        var getAddresses = function(item){
            let endpoint = 'json/addresses.json?personid='+item.personId;
            return $http.get(endpoint).then( function (response) {
                let addresses = response.data;
                addresses.pop();
                item.addresses = angular.copy(addresses);
                if(addresses.length > 0){
                    item.primaryAddress = angular.copy(addresses[0]);
                }
            });
        };

        var mergeObjectArrays = function(arr1, arr2, key) {
            const merged = [...arr1];

            arr2.forEach(obj2 => {
                const exists = merged.some(obj1 => obj1[key] === obj2[key]);
                if (!exists) {
                merged.push(obj2);
                }
            });

            return merged;
        };

        $scope.searchForContacts = function(contactInfo){
            loadingDialog();
            let searchByCategories = [
                {
                    'name': 'name',
                    'enabled': contactInfo.nameFirst.concat(contactInfo.nameLast).length > 0
                },
                {
                    'name': 'phone',
                    'enabled': contactInfo.preferredphonenumber.length > 0
                },
                {
                    'name': 'email',
                    'enabled': contactInfo.primaryemail.length > 0
                }
            ];
            let searchPromises = [];
            let searchResults = [];
            let foundContacts = [];
            
            searchByCategories.forEach((category, index) => {
                let endpoint = 'json/contactsearch.json?searchby='+category.name+'&firstname='+encodeURIComponent(contactInfo.nameFirst)+'&lastname='+encodeURIComponent(contactInfo.nameLast)+'&phone='+encodeURIComponent(contactInfo.preferredphonenumber)+'&email='+encodeURIComponent(contactInfo.primaryemail);
                if(category.enabled){
                    searchPromises.push($http.get(endpoint).then( function (response) {
                        let contacts = response.data;
                        contacts.pop();
                        searchResults.push(contacts);
                    }));
                }
            });

            if(searchPromises.length > 0){
                $q.all(searchPromises).then(function(){
                    if(searchResults.length > 1){
                        searchResults.forEach((resultArray) => {
                            foundContacts = mergeObjectArrays(foundContacts, resultArray, 'personId');
                        });
                    }
                    else {
                        foundContacts = searchResults[0];
                    }
                    $scope.searchResults = foundContacts;
                    
                }).then(function(){
                    foundContacts.forEach((contact) => {
                        let detailPromises = [];
                        detailPromises.push(getPhoneNumbers(contact));
                        detailPromises.push(getEmailAddresses(contact));
                        detailPromises.push(getAddresses(contact));
                        $q.all(detailPromises);
                    });
                });
            }
            closeLoading();
        };

        /*
        $scope.$watch('selectedContact', function(newValue, oldValue) {
            if(newValue.personId == 0){
                $scope.$emit('disable.button.btnSelectAndAssociate');
            }
            else{
                $scope.$emit('enable.button.btnSelectAndAssociate');
            }
            $scope.$apply();
        });
        */
        

    }); // END: Contact Search Controller (contactSearchController)
    
});