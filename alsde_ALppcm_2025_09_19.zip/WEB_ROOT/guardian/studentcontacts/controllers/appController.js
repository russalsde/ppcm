define(['angular', 'components/shared/index'], function (angular) {
   
    var ppContactsApp = angular.module('ppContactsApp', ['powerSchoolModule']).run(function($rootScope, $http) {

        var getRelationshipCodes = function(){
            let endpoint = 'codeset.json?type=Relationship';
                $http.get(endpoint).then( function (response) {
                    var codeset = response.data;
                    codeset.pop();
                    $rootScope.relationshipCodes = codeset;
                });
        };

        var getPhoneTypeCodes = function(){
                let endpoint = 'codeset.json?type=Phone';
                    $http.get(endpoint).then( function (response) {
                        var codeset = response.data;
                        codeset.pop();
                        $rootScope.phoneTypeCodes = codeset;
                    });

        }; 

        var getEmailTypeCodes = function(){
                let endpoint = 'codeset.json?type=Email';
                    $http.get(endpoint).then( function (response) {
                        var codeset = response.data;
                        codeset.pop();
                        $rootScope.emailTypeCodes = codeset;
                    });

        }; 

        var getAddressTypeCodes = function(){
                let endpoint = 'codeset.json?type=Address';
                    $http.get(endpoint).then( function (response) {
                        var codeset = response.data;
                        codeset.pop();
                        $rootScope.addressTypeCodes = codeset;
                    });

        }; 

        var getStateTypeCodes = function(){
                let endpoint = 'codeset.json?type=State';
                    $http.get(endpoint).then( function (response) {
                        var codeset = response.data;
                        codeset.pop();
                        $rootScope.stateTypeCodes = codeset;
                    });
        };
       
        /*
        var getNamePrefixCodes = function(){
            let endpoint = 'codeset.json?type=Prefix';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.namePrefixCodes = codeset;
            });
        };
        */

        var getNameSuffixCodes = function(){
            let endpoint = 'codeset.json?type=Suffix';
            $http.get(endpoint).then( function (response) {
                var codeset = response.data;
                codeset.pop();
                $rootScope.nameSuffixCodes = codeset;
            });

        };

        getRelationshipCodes();
        getPhoneTypeCodes();
        getEmailTypeCodes();
        getAddressTypeCodes();
        getStateTypeCodes();
        //getNamePrefixCodes();
        getNameSuffixCodes();

    });

    // Codeset service
    ppContactsApp.service('codesetService', function($http) {
        var data = [];
        return {
            getCodeSet: function(codeset) {
                let endpoint = 'codeset.json?type='+codeset;
                $http.get(endpoint).then( function (response) {
                    var codeset = response.data;
                    codeset.pop();
                    data = angular.copy(codeset);
                    return data;
                });
            }
        };
    });

    ppContactsApp.filter('thisstudent', function() {
            return function (object,thisdcid) {
                //let students = [];
                //console.log('object');
                //console.log(object[0].requestjson.studentrelationships);
                //console.log('student dcid');
                //console.log(thisdcid);
                //students = angular.copy(object[0].requestjson.studentrelationships);
                object[0].requestjson.studentrelationships.forEach(function (student) {
                    
                    if (Number(student.studentdcid) == Number(thisdcid)) {
                        console.log(student.studentdcid + ' - ' + thisdcid);
                        return true;
                    }
                    else{
                        return false;
                    }
                });
            };
        });

    // Contact storage service
    ppContactsApp.service('contactService', function() {
        var data = {};
        return {
            getData: function() {
                return data;
            },
            setData: function(newData) {
                data = newData;
            }
        };
    });
   

    ppContactsApp.controller('appController', function($scope, $rootScope, $http, $window, $httpParamSerializer, $location, contactService){
        
        $rootScope.$on("CallRefreshContacts", function(){
            $scope.refreshContacts();
        });
    
        $scope.refreshContacts = function() {
            getStudentContacts($scope.studentRn);
        };

        $rootScope.$on("CallRefreshPendingRequests", function(){
            $scope.refreshPendingRequests();
        });
    
        $scope.refreshPendingRequests = function() {
            getMyPendingRequests($scope.studentRn, $scope.guardianId);
        };
        
        $scope.myMessage = 'Hola!';
        $scope.studentRn = '';
        $scope.guardianId = '';
        $scope.studentContacts = [];
        $scope.canManageContacts = false;
        $scope.myPendingRequests = [];
        $scope.displayContacts = false;
        $scope.displayDebugInfo = false;

        $scope.addressObject = {};
        $scope.emailaddressObject = {};
        $scope.phonenumberObject = {};
        
        
        $scope.appInit = function(studentRn, guardianId){
            $scope.studentRn = studentRn;
            $scope.guardianId = guardianId;
            getStudentContacts(studentRn);
            getMyPendingRequests(studentRn, guardianId);
        };

        var getMyPendingRequests = function(studentRn, guardianId){
            let endpoint = 'pendingrequests.json?gid='+guardianId+'&sid='+studentRn;
            $scope.myPendingRequests = [];
            $http.get(endpoint).then( function (response) {
                var pendingRequests = response.data;
                pendingRequests.pop();
                pendingRequests.forEach(function(item){
                    item.requestjson = JSON.parse(item.requestjson);
                    item.requestjson.studentrelationships.forEach(function(student){
                        if((student.studentdcid == studentRn) && student.selected){
                            $scope.myPendingRequests.push(item);            
                        }
                    });
                });
                //$scope.myPendingRequests = angular.copy(pendingRequests);
                console.log($scope.myPendingRequests);
            });
        };
                
        var getStudentContacts = function(iStudentRn) {
            let endpoint = 'contacts.json?studentrn='+iStudentRn;
            $http.get(endpoint).then( function (response) {
                var studentContacts = response.data;
                studentContacts.pop();

                studentContacts.forEach(checkManageMyContacts);
                studentContacts.forEach(checkManageAnyContacts);
                studentContacts.forEach(getPhoneNumbers);
                studentContacts.forEach(getEmailAddresses);
                studentContacts.forEach(getAddresses);
                studentContacts.forEach(checkforPendingRequests);
        
                $scope.studentContacts = studentContacts;
                
            }).finally( function (){
                // NOTE: If the logged in user is not allowed to manage contacts then redirect to the parent portal home page
                /*
                if($scope.canManageContacts != true){
                    $window.location.href = '../home.html';
                }
                else {
                    $scope.displayContacts = true;
                    console.log($scope.studentContacts);
                }
                */
                $scope.displayContacts = true;
                console.log($scope.studentContacts);
            });
            
        };

        var checkManageMyContacts = function(item) {
            if((item.canManageContacts == '1') && (item.guardianId == $scope.guardianId)){
                $scope.canManageContacts = true;
            }
        };

        var checkManageAnyContacts = function(item){
            let endpoint = 'mc_check.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var studentDcids = response.data;
                studentDcids.pop();
                if(studentDcids.length > 0){
                    item.dcCheck = 1;
                }
                else{
                    item.dcCheck = 0;
                }
                
            });
        };

        var getPhoneNumbers = function(item){
            let endpoint = 'phonenumbers.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var phoneNumbers = response.data;
                phoneNumbers.pop();
                item.phonenumbers = phoneNumbers;
                if(phoneNumbers.length > 0){
                    item.primaryPhoneNumber = phoneNumbers[0];
                    for(var j = 0; j < phoneNumbers.length; j++){
                        if (phoneNumbers[j].isPreferred === '1') { item.primaryPhoneNumber = phoneNumbers[j]; break; }
                    }
                }
                else{
                    // NOTE: handle contact with no phone numbers
                    var noPhoneNumber = {
                        'phoneType' : 'Not Set',
                        'phoneTypeCodeSetId' : $rootScope.phoneTypeCodes.find(item => item.code === 'Not Set').codesetId,
                        'phonenumber' : '',
                        'phonenumberAsEntered' : '',
                        'phonenumberId' : '-1',
                        'ext' : '',
                        'isPreferred' : '1',
                        'isSMS' : '0',
                        'personphonenumberassocId' : '0',
                        'priorityOrder' : '1',
                    };
                    item.primaryPhoneNumber = noPhoneNumber;
                    
                }
                
            });
        };

        var getEmailAddresses = function(item){
            let endpoint = 'emailaddresses.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var emailAddresses = response.data;
                emailAddresses.pop();
                item.emailaddresses = emailAddresses;
                if(emailAddresses.length > 0){
                    item.primaryEmailAddress = emailAddresses.find(item => item.isPrimary === '1');
                }
                else{
                    // NOTE: handle contact with no email addresses
                    var noEmail = {
                        'emailType' : 'Not Set',
                        'emailTypeCodeSetId' : $rootScope.emailTypeCodes.find(item => item.code === 'Not Set').codesetId,
                        'emailAddress' : '',
                        'emailaddressId' : '-1',
                        'emailaddressassocId' : '0',
                        'isPrimary' : '1',
                        'priorityOrder' : '1'
                    };
                    item.primaryEmailAddress = noEmail;
                }
            });
        };

        var getAddresses = function(item){
            let endpoint = 'addresses.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var addresses = response.data;
                addresses.pop();
                item.addresses = addresses;
                if(addresses.length > 0){
                    item.primaryAddress = addresses[0];
                }
                else{
                    // NOTE: handle contact with no physical addresses
                    var noAddress = {
                        'addressType' :'Not Set',
                        'addressTypeCodeSetId' : $rootScope.addressTypeCodes.find(item => item.code === 'Not Set').codesetId,
                        'city' : '',
                        'country' : 'United States',
                        'endDate' : '',
                        'linetwo' : '',
                        'personaddressassocId' : '0',
                        'postalcode' : '',
                        'state' : 'Not Set',
                        'statecodesetId' : $rootScope.stateTypeCodes.find(item => item.code === 'Not Set').codesetId,
                        'personaddressId' : '-1',
                        'priorityOrder' : '1',
                        'startDate' : '',
                        'street' : '',
                        'unit' : ''
                    };
                    item.primaryAddress = noAddress;
                }
            });
        };

        var checkforPendingRequests = function(item){
            let endpoint = 'requests.json?personid='+item.personId;
            $http.get(endpoint).then( function (response) {
                var changeRequests = response.data;
                changeRequests.pop();
                item.changeRequests = changeRequests;
                if(changeRequests.length > 0){
                    item.pendingRequests = changeRequests[0];
                    item.hasPendingRequests = true;
                }
            });
        };

        $scope.editContact = function(contact){
            //contactService.setData(contact);
            $window.location.href = 'contact.html?pid='+contact.personId;
        };
        
    }); // end app controller
   
   ppContactsApp.controller('changeRequestController', function($scope, $http, $httpParamSerializer){
       
       $scope.contact = {};
       
       var init = function() {
           
           $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.contact = properties.data;
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                // TODO: clear contact object
                callback();
            });
            
            $scope.$emit('save.drawer.event', function(callback, properties) {
                // TODO: save local request record??
                // TODO: clear contact object
                
                var changeRequest = {};
                angular.forEach($scope.requestform, function (element, name) {
                    if (name.startsWith('CF-')) {
                        changeRequest[name] = angular.element('[name="'+name+'"]').val();
                    }
                });
                changeRequest["ac"] = "autosendupdate";
                changeRequest["id"] = "-1";
                
                
                $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    
                $http({
                    method: 'POST',
                    url: 'white.html',
                    data: $j.param(changeRequest),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                }).success(function (data, status, headers, config) {
                    // handle success things
                }).error(function (data, status, headers, config) {
                    // handle error things
                });
               
                callback();
            });
            
       };
       
       init();
       
   }); // end controller
   
   ppContactsApp.controller('associateController', function($scope, $rootScope, $http, $httpParamSerializer){
       
    //$scope.contact = {};
    
    var init = function() {
        
        $scope.$emit('open.drawer.event', function(callback, properties) {
             //$scope.contact = properties.data;
             callback();
         });
         
         $scope.$emit('cancel.drawer.event', function(callback, properties) {
             // TODO: clear contact object
             callback();
         });
         
         $scope.$emit('save.drawer.event', function(callback, properties) {
             // TODO: save local request record??
             // TODO: clear contact object
             
             var changeRequest = {};
             
             //changeRequest["STUDENTCONTACTASSOC.STUDENTCONTACTASSOCID"] = "-1";
             changeRequest["STUDENTCONTACTASSOC.STUDENTDCID"] = "5055";
             changeRequest["STUDENTCONTACTASSOC.PERSONID"] = "33754";
             changeRequest["ac"] = "autosendupdate";
             
             console.log(changeRequest);
             
             $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
 
             $http({
                 method: 'POST',
                 url: 'white.html',
                 data: $j.param(changeRequest),
                 headers: {'Content-Type': 'application/x-www-form-urlencoded'}
             }).success(function (data, status, headers, config) {
                 $rootScope.$emit("CallRefreshContacts", {});
             }).error(function (data, status, headers, config) {
                 // handle error things
             });
             
             callback();
         });
         
    };
    
    init();
    
}); // end controller

   ppContactsApp.controller('disassociateController', function($scope, $rootScope, $http, $httpParamSerializer){
       
       $scope.contact = {};
       
       var init = function() {
           
           $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.contact = properties.data;
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                // TODO: clear contact object
                callback();
            });
            
            $scope.$emit('save.drawer.event', function(callback, properties) {
                // TODO: save local request record??
                // TODO: clear contact object
                
                var changeRequest = {};
                /*
                angular.forEach($scope.disassociateform, function (element, name) {
                    if (name.startsWith('CF-')) {
                        changeRequest[name] = 0;
                    }
                    console.log(name);
                    
                    if (name.startsWith('stuconassocid')) {
                        changeRequest["studentcontactassocid"] = angular.element('[name="'+name+'"]').val();
                    }
                    
                });
                */
                /*
                changeRequest["CF-[STUDENTCONTACTASSOC:" + $scope.contact["studentContactAssocId"] + "]STUDENTDCID$format=numeric"] = "0";
                */
                //name="DD-u_lib_book.id:~(gpv.bookid)" value="1"
                changeRequest["DD-STUDENTCONTACTASSOC.STUDENTCONTACTASSOCID:" + $scope.contact["studentContactAssocId"]] = "1";
                changeRequest["ac"] = "autosendupdate";
                //changeRequest["studentcontactassocid"] = "-1";
                
                console.log(changeRequest);
                
                $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    
                $http({
                    method: 'POST',
                    url: 'white.html',
                    data: $j.param(changeRequest),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                }).success(function (data, status, headers, config) {
                    $rootScope.$emit("CallRefreshContacts", {});
                }).error(function (data, status, headers, config) {
                    // handle error things
                });
                
                callback();
            });
            
       };
       
       init();
       
   }); // end controller

   ppContactsApp.controller('deleterequestController', function($scope, $rootScope, $http, $httpParamSerializer){
       
    $scope.request = {};
    
    var init = function() {
        
        $scope.$emit('open.drawer.event', function(callback, properties) {
             $scope.request = angular.copy(properties.data);
             callback();
         });
         
         $scope.$emit('cancel.drawer.event', function(callback, properties) {
             // TODO: clear contact object
             callback();
         });
         
         $scope.$emit('save.drawer.event', function(callback, properties) {
             
            var changeRequest = {};
             
             changeRequest["DD-U_PPCM_REQUESTS.ID:" + $scope.request["id"]] = "1";
             changeRequest["ac"] = "autosendupdate";
             
             $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
 
             $http({
                 method: 'POST',
                 url: 'white.html',
                 data: $j.param(changeRequest),
                 headers: {'Content-Type': 'application/x-www-form-urlencoded'}
             }).success(function (data, status, headers, config) {
                 $rootScope.$emit("CallRefreshContacts", {});
                 $rootScope.$emit("CallRefreshPendingRequests", {});
             }).error(function (data, status, headers, config) {
                 // handle error things
             });
             
             callback();
         });
         
    };
    
    init();
    
}); // end controller

    // ppcm-validation directive

    ppContactsApp.directive('ppcmValidation', function() {
        return {
            require: 'ngModel',
            link: function(scope, element, attr, mCtrl) {
                function testForEmpty(value) {
                    console.log(value);
                    if (value.length  == 0) {
                        mCtrl.$setValidity('zeroLen', false);
                    } else {
                        mCtrl.$setValidity('zeroLen', true);
                    }
                    return value;
                }
            }
        };
    }); // end ppcm-validation directive

   
   ppContactsApp.controller('editController', function($scope, $rootScope, $http, $httpParamSerializer){
       
       $scope.contact = {};
       $scope.contactOriginal = {};
       $scope.relationshipCodes = $rootScope.relationshipCodes;
       $scope.phoneTypeCodes = $rootScope.phoneTypeCodes;
       $scope.emailTypeCodes = $rootScope.emailTypeCodes;
       $scope.addressTypeCodes = $rootScope.addressTypeCodes;
       $scope.stateTypeCodes = $rootScope.stateTypeCodes;

       $scope.textOnlyPattern = /^[a-zA-Z '-]{1,25}$/;

       $scope.showAlert = function(){
            $scope.trueValue = "1";
       };

       $scope.selectedPrimaryEmailAddressId = '0';
       $scope.showEmailEntry = false;
       $scope.toggleEmailAddressEntry = function(){
            console.log(angular.element('#primaryEmailAddressIdSelect').val());
            //$scope.contact.primaryEmailAddress.emailaddressassocId
            if(angular.element('#primaryEmailAddressIdSelect').val() == '-1'){
                $scope.showEmailEntry = true;
                console.log('show email entry');
            }
            else{
                $scope.showEmailEntry = false;
                console.log('hide email entry');
            }
       };

       var init = function() {
           
           $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.contact = properties.data;
                $scope.selectedPrimaryEmailAddressId = $scope.contact.primaryEmailAddress.emailaddressId;
                $scope.contactOriginal = angular.copy($scope.contact);
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                $scope.contactOriginal = angular.copy($scope.contact);
                properties.data = angular.copy($scope.contactOriginal);
                $scope.contact = {};
                callback();
            });
            
            $scope.$emit('save.drawer.event', function(callback, properties) {
                if($scope.associationform.$valid){
                    $j("#associationform").submit();
                }
                else{
                    console.log($scope.associationform.$error);
                }
            });
       };
       
       init();
       
       
   }); // end controller
    
});