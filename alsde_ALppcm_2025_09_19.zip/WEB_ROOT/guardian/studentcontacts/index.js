'use strict';
define(function(require) {
    require('controllers/appController.js');
    require('controllers/contactController.js');
    require('controllers/newcontactController.js');
});